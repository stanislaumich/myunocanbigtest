# LarduinoISP
make arduino board to be an ISP of LGT8FX8D series MCU

